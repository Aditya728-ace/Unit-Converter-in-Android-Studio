package com.example.ucdropdown;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    String[] item1 = {"Data", "Length", "Mass", "Temperature", "Time"};
    TextView t;
    //data 20   length 30  mass 40  speed 50  temp  60   time 70

    String[] dataitem = {"KB", "MB", "GB", "TB", "PB"};
    int mainpos;
    String mainop = "";
    String[] dataitem2 = {"KB", "MB", "GB", "TB", "PB"};

    String[] Length = {"km", "m", "cm", "feet", "inch"};

    String[] Length1 = {"km", "m", "cm", "feet", "inch"};

    String[] Mass = {"kg", "gm", "quintal", "tonne"};

    String[] Mass1 = {"kg", "gm", "quintal", "tonne"};


    String[] Temp = {"Celsius", "Fahrenheit", "Kelvin"};

    String[] Temp1 = {"Celsius", "Fahrenheit", "Kelvin"};

    String[] Time = {"year", "month", "week", "days", "hrs", "min", "sec"};

    String[] Time1 = {"year", "month", "week", "days", "hrs", "min", "sec"};
    AutoCompleteTextView autoCompleteTextView1, autoCompleteTextView2, autoCompleteTextView3;

    ArrayAdapter<String> adapterItems1, adapterItems2, adapterItems3;
    converter c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        t = (TextView) findViewById(R.id.textView);
        autoCompleteTextView1 = findViewById(R.id.auto_complete_txt1);
        adapterItems1 = new ArrayAdapter<String>(this, R.layout.list_item, item1);
        autoCompleteTextView1.setAdapter(adapterItems1);

        autoCompleteTextView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                String item = adapterView.getItemAtPosition(i).toString();


                Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                setalldata(i,item);
                c=new converter(item);
            }
        });

    }
    void setalldata(int pos,String name)
    {

        if(pos==0) {
            autoCompleteTextView2 = findViewById(R.id.auto_complete_txt2);
            adapterItems2 = new ArrayAdapter<String>(this, R.layout.list_item,dataitem);
            autoCompleteTextView2.setAdapter(adapterItems2);

            autoCompleteTextView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String   item = adapterView.getItemAtPosition(i).toString();

                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(item,c);
                }
            });
            autoCompleteTextView3 = findViewById(R.id.auto_complete_txt3);
            adapterItems3 = new ArrayAdapter<String>(this, R.layout.list_item, dataitem2);
            autoCompleteTextView3.setAdapter(adapterItems3);

            autoCompleteTextView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(c,item);
                }
            });
        }
        if(pos==1) {
            autoCompleteTextView2 = findViewById(R.id.auto_complete_txt2);
            adapterItems2 = new ArrayAdapter<String>(this, R.layout.list_item, Length);
            autoCompleteTextView2.setAdapter(adapterItems2);

            autoCompleteTextView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String   item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(item,c);
                }
            });
            autoCompleteTextView3 = findViewById(R.id.auto_complete_txt3);
            adapterItems3 = new ArrayAdapter<String>(this, R.layout.list_item, Length1);
            autoCompleteTextView3.setAdapter(adapterItems3);

            autoCompleteTextView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(c,item);
                }
            });
        }
        if(pos==2) {
            autoCompleteTextView2 = findViewById(R.id.auto_complete_txt2);
            adapterItems2 = new ArrayAdapter<String>(this, R.layout.list_item, Mass);
            autoCompleteTextView2.setAdapter(adapterItems2);

            autoCompleteTextView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String   item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(item,c);
                }
            });
            autoCompleteTextView3 = findViewById(R.id.auto_complete_txt3);
            adapterItems3 = new ArrayAdapter<String>(this, R.layout.list_item, Mass1);
            autoCompleteTextView3.setAdapter(adapterItems3);

            autoCompleteTextView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(c,item);
                }
            });
        }

        if(pos==3) {
            autoCompleteTextView2 = findViewById(R.id.auto_complete_txt2);
            adapterItems2 = new ArrayAdapter<String>(this, R.layout.list_item, Temp);
            autoCompleteTextView2.setAdapter(adapterItems2);

            autoCompleteTextView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String   item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(item,c);
                }
            });
            autoCompleteTextView3 = findViewById(R.id.auto_complete_txt3);
            adapterItems3 = new ArrayAdapter<String>(this, R.layout.list_item, Temp1);
            autoCompleteTextView3.setAdapter(adapterItems3);

            autoCompleteTextView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(c,item);
                }
            });
        }
        if(pos==4) {
            autoCompleteTextView2 = findViewById(R.id.auto_complete_txt2);
            adapterItems2 = new ArrayAdapter<String>(this, R.layout.list_item, Time);
            autoCompleteTextView2.setAdapter(adapterItems2);

            autoCompleteTextView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String   item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(item,c);
                }
            });
            autoCompleteTextView3 = findViewById(R.id.auto_complete_txt3);
            adapterItems3 = new ArrayAdapter<String>(this, R.layout.list_item, Time1);
            autoCompleteTextView3.setAdapter(adapterItems3);

            autoCompleteTextView3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    String item = adapterView.getItemAtPosition(i).toString();
                    mainpos = i;
                    mainop = item.toString();
                    Toast.makeText(MainActivity.this, "Item: " + item, Toast.LENGTH_SHORT).show();
                    converter c2=new converter(c,item);
                }
            });
        }

        Button b1;
        b1=(Button)findViewById(R.id.button);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText e1;
                TextView t1;
                e1=(EditText) findViewById(R.id.editTextNumberDecimal);
                t1=(TextView) findViewById(R.id.textView);
                double ans,num1;
                String str1;
                String str;
                str=e1.getText().toString();
                num1=Double.parseDouble(str);
                str1=c.calculate(num1);
                str=str1+"";
                t1.setText(str);

            }
        });
    }
}
class converter {
    String op1, op2, op3;

    public converter(String i) {
        op1 = i;
    }

    public converter(String i, converter c) {
        c.op2 = i;
    }

    public converter(converter c, String i) {
        c.op3 = i;
    }

    String calculate(double num1) {
        double ans = 0;
        if (op1.compareTo("Length") == 0) {
            if (op2.compareTo("km") == 0 && op3.compareTo("m") == 0) {

                ans = (num1 * 1000);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("km") == 0 && op3.compareTo("cm") == 0)) {
                ans = num1 * 100000;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("km") == 0 && op3.compareTo("km") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("km") == 0 && op3.compareTo("feet") == 0)) {
                ans = num1 * 3280.84;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("km") == 0 && op3.compareTo("inch") == 0)) {
                ans = num1 * 39370.1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("m") == 0 && op3.compareTo("m") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("m") == 0 && op3.compareTo("km") == 0)) {
                ans = num1 / 1000;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("m") == 0 && op3.compareTo("cm") == 0)) {
                ans = num1 * 100;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("m") == 0 && op3.compareTo("feet") == 0)) {
                ans = num1 * 3.28399;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("m") == 0 && op3.compareTo("inch") == 0)) {
                ans = num1 * 39.37;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("cm") == 0 && op3.compareTo("cm") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("cm") == 0 && op3.compareTo("km") == 0)) {
                ans = num1 * 0.00001;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("cm") == 0 && op3.compareTo("m") == 0)) {
                ans = num1 * 0.01;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("cm") == 0 && op3.compareTo("feet") == 0)) {
                ans = num1 * 0.033;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("cm") == 0 && op3.compareTo("inch") == 0)) {
                ans = num1 * 0.3937;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("feet") == 0 && op3.compareTo("feet") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("feet") == 0 && op3.compareTo("km") == 0)) {
                ans = num1 * 0.0003048;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("feet") == 0 && op3.compareTo("cm") == 0)) {
                ans = num1 * 30.48;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("feet") == 0 && op3.compareTo("m") == 0)) {
                ans = num1 * 0.348;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("feet") == 0 && op3.compareTo("inch") == 0)) {
                ans = num1 * 12;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("inch") == 0 && op3.compareTo("km") == 0)) {
                ans = num1 * 0.0000254;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("inch") == 0 && op3.compareTo("m") == 0)) {
                ans = num1 * 0.0254;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("inch") == 0 && op3.compareTo("cm") == 0)) {
                ans = num1 * 2.54;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("inch") == 0 && op3.compareTo("feet") == 0)) {
                ans = num1 * 0.0833333;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("inch") == 0 && op3.compareTo("inch") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);

            }
            //data
        }
        if (op1.compareTo("Data") == 0) {
            if (op2.compareTo("KB") == 0 && op3.compareTo("KB") == 0) {

                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("KB") == 0 && op3.compareTo("MB") == 0)) {
                ans = num1 / 1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("KB") == 0 && op3.compareTo("GB") == 0)) {
                ans = num1 * 1/(1024*1024);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("KB") == 0 && op3.compareTo("TB") == 0)) {
                ans = num1 * 1/(1024*1024*1024);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("KB") == 0 && op3.compareTo("PB") == 0)) {

                // return String.valueOf((num1 /(1048576))/(1048576)+ " " + op3);
                return String.valueOf(num1 /((10485.76*10485.76)*10000)+ " " + op3);
            } else if ((op2.compareTo("MB") == 0 && op3.compareTo("MB") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("MB") == 0 && op3.compareTo("KB") == 0)) {
                ans = num1 * 1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("MB") == 0 && op3.compareTo("GB") == 0)) {
                ans = num1 * 1/1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("MB") == 0 && op3.compareTo("TB") == 0)) {
                ans = num1 * 1/(1024*1024);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("MB") == 0 && op3.compareTo("PB") == 0)) {
                ans = num1 * 1/(1024*1024*1024);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("GB") == 0 && op3.compareTo("GB") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("GB") == 0 && op3.compareTo("KB") == 0)) {
                ans = num1 * (1024*1024);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("GB") == 0 && op3.compareTo("MB") == 0)) {
                ans = num1 * 1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("GB") == 0 && op3.compareTo("TB") == 0)) {
                ans = num1 * 1/1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("GB") == 0 && op3.compareTo("PB") == 0)) {
                ans = num1 * 1/(1024*1024);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("TB") == 0 && op3.compareTo("TB") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("TB") == 0 && op3.compareTo("GB") == 0)) {
                ans = num1 * 1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("TB") == 0 && op3.compareTo("KB") == 0)) {
                ans = num1 * (1024*1024*1024);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("TB") == 0 && op3.compareTo("PB") == 0)) {
                ans = num1*1/1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("TB") == 0 && op3.compareTo("MB") == 0)) {
                ans = num1 * 1024*1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("PB") == 0 && op3.compareTo("PB") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("PB") == 0 && op3.compareTo("KB") == 0)) {
                ans = num1*1024*1024*1024*1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("PB") == 0 && op3.compareTo("MB") == 0)) {
                ans = num1*1024*1024*1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("PB") == 0 && op3.compareTo("GB") == 0)) {
                ans = num1*1024*1024;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("PB") == 0 && op3.compareTo("TB") == 0)) {
                ans = num1*1024;
                return String.valueOf(ans + " " + op3);
            }
        }
        //mass
        if (op1.compareTo("Mass") == 0) {
            if (op2.compareTo("kg") == 0 && op3.compareTo("kg") == 0) {

                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("kg") == 0 && op3.compareTo("gm") == 0)) {
                ans = num1 * 1000;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("kg") == 0 && op3.compareTo("quintal") == 0)) {
                ans = num1 * 0.01;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("kg") == 0 && op3.compareTo("tonne") == 0)) {
                ans = num1 * 0.001;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("gm") == 0 && op3.compareTo("gm") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("gm") == 0 && op3.compareTo("kg") == 0)) {
                ans = num1 * 0.001;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("gm") == 0 && op3.compareTo("quintal") == 0)) {
                ans = num1 * 0.00001;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("gm") == 0 && op3.compareTo("tonne") == 0)) {
                ans = num1 * 0.000001;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("quintal") == 0 && op3.compareTo("quintal") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("quintal") == 0 && op3.compareTo("kg") == 0)) {
                ans = num1 * 100;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("quintal") == 0 && op3.compareTo("gm") == 0)) {
                ans = num1 * 100000;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("quintal") == 0 && op3.compareTo("tonne") == 0)) {
                ans = num1 * 0.1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("tonne") == 0 && op3.compareTo("tonne") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("tonne") == 0 && op3.compareTo("quintal") == 0)) {
                ans = num1 * 10;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("tonne") == 0 && op3.compareTo("kg") == 0)) {
                ans = num1 * 1000;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("tonne") == 0 && op3.compareTo("gm") == 0)) {
                ans = num1 * 10000000;
                return String.valueOf(ans + " " + op3);
            }
        }
        if (op1.compareTo("Temperature") == 0) {
            if (op2.compareTo("Celsius") == 0 && op3.compareTo("Celsius") == 0) {

                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Celsius") == 0 && op3.compareTo("Fahrenheit") == 0)) {
                ans = (9*num1/5)+32;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Celsius") == 0 && op3.compareTo("Kelvin") == 0)) {
                ans = num1 +274.5;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Fahrenheit") == 0 && op3.compareTo("Celsius") == 0)) {
                ans =0.555555556*(num1-32);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Fahrenheit") == 0 && op3.compareTo("Fahrenheit") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Fahrenheit") == 0 && op3.compareTo("Kelvin") == 0)) {
                ans = 0.555555556*(num1-32)+273.15;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Kelvin") == 0 && op3.compareTo("Celsius") == 0)) {
                ans = num1 * num1-273.15;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Kelvin") == 0 && op3.compareTo("Fahrenheit") == 0)) {
                ans = 1.8*(num1-273.15)+32;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("Kelvin") == 0 && op3.compareTo("Kelvin") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            }
        }
        if (op1.compareTo("Time") == 0) {
            if (op2.compareTo("year") == 0 && op3.compareTo("year") == 0) {

                ans = (num1);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("year") == 0 && op3.compareTo("month") == 0)) {
                ans = num1 * 12;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("year") == 0 && op3.compareTo("week") == 0)) {
                ans = num1*52;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("year") == 0 && op3.compareTo("days") == 0)) {
                ans = num1 * 365;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("year") == 0 && op3.compareTo("hrs") == 0)) {
                ans = num1 *8760;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("year") == 0 && op3.compareTo("min") == 0)) {
                ans = num1*525600;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("year") == 0 && op3.compareTo("sec") == 0)) {
                ans = num1*525600*60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("month") == 0 && op3.compareTo("year") == 0)) {
                ans = num1/12;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("month") == 0 && op3.compareTo("month") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("month") == 0 && op3.compareTo("week") == 0)) {
                ans = num1*4;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("month") == 0 && op3.compareTo("days") == 0)) {
                ans = num1*30;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("month") == 0 && op3.compareTo("hrs") == 0)) {
                ans = num1 * 30*24;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("month") == 0 && op3.compareTo("min") == 0)) {
                ans = num1 * 30*24*60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("month") == 0 && op3.compareTo("sec") == 0)) {
                ans = num1 * 30*24*60*60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("week") == 0 && op3.compareTo("year") == 0)) {
                ans = num1/52;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("week") == 0 && op3.compareTo("month") == 0)) {
                ans = num1/4;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("week") == 0 && op3.compareTo("week") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("week") == 0 && op3.compareTo("days") == 0)) {
                ans = num1*7;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("week") == 0 && op3.compareTo("hrs") == 0)) {
                ans = num1 *7*24;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("week") == 0 && op3.compareTo("min") == 0)) {
                ans = num1 * num1 *7*24*60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("week") == 0 && op3.compareTo("sec") == 0)) {
                ans = num1 * num1 *7*24*60*60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("days") == 0 && op3.compareTo("year") == 0)) {
                ans = num1/365;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("days") == 0 && op3.compareTo("month") == 0)) {
                ans = num1/30;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("days") == 0 && op3.compareTo("week") == 0)) {
                ans = num1/7;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("days") == 0 && op3.compareTo("days") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("days") == 0 && op3.compareTo("hrs") == 0)) {
                ans = num1 * 24;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("days") == 0 && op3.compareTo("min") == 0)) {
                ans = num1 * (24*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("days") == 0 && op3.compareTo("sec") == 0)) {
                ans = num1 * (24*60*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("hrs") == 0 && op3.compareTo("year") == 0)) {
                ans = num1/(365*24);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("hrs") == 0 && op3.compareTo("month") == 0)) {
                ans = num1*0.00137;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("hrs") == 0 && op3.compareTo("week") == 0)) {
                ans = num1*0.00595238095;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("hrs") == 0 && op3.compareTo("days") == 0)) {
                ans = num1*0.0417;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("hrs") == 0 && op3.compareTo("hrs") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("hrs") == 0 && op3.compareTo("min") == 0)) {
                ans = num1*60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("hrs") == 0 && op3.compareTo("sec") == 0)) {
                ans = num1*(60*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("min") == 0 && op3.compareTo("year") == 0)) {
                ans = num1/(365*24*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("min") == 0 && op3.compareTo("month") == 0)) {
                ans = num1/(30*24*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("min") == 0 && op3.compareTo("week") == 0)) {
                ans = num1/(7*24*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("min") == 0 && op3.compareTo("days") == 0)) {
                ans = num1/(24*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("min") == 0 && op3.compareTo("hrs") == 0)) {
                ans = num1/60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("min") == 0 && op3.compareTo("min") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("min") == 0 && op3.compareTo("sec") == 0)) {
                ans = num1*60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("sec") == 0 && op3.compareTo("year") == 0)) {
                ans = num1/(365*24*60*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("sec") == 0 && op3.compareTo("month") == 0)) {
                ans = num1/(30*24*60*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("sec") == 0 && op3.compareTo("week") == 0)) {
                ans = num1/(7*24*60*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("sec") == 0 && op3.compareTo("days") == 0)) {
                ans = num1/(24*60*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("sec") == 0 && op3.compareTo("hrs") == 0)) {
                ans = num1/(60*60);
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("sec") == 0 && op3.compareTo("min") == 0)) {
                ans = num1/60;
                return String.valueOf(ans + " " + op3);
            } else if ((op2.compareTo("sec") == 0 && op3.compareTo("sec") == 0)) {
                ans = num1;
                return String.valueOf(ans + " " + op3);
            }
        }






        return String.valueOf(ans);

    }


}